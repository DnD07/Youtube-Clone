import React from 'react'
import './Header.css'
import MenuIcon from '@mui/icons-material/Menu';
import Searchicon from '@mui/icons-material/Search'
import VideoCall from '@mui/icons-material/VideoCall'
import AppsIcon from '@mui/icons-material/Apps';
import NotificationsIcon from '@mui/icons-material/Notifications';
import Avatar from '@mui/material/Avatar'
import Sagar from '../Images/sagar.jpg'


export default function Header() {
  return( 
    <div className='header'>
      <div className='header_left'>
    <MenuIcon/>
    <img
    className='header_logo' 
    src='https://upload.wikimedia.org/wikipedia/commons/e/e1/Logo_of_YouTube_%282015-2017%29.svg' alt='youtube-logo'/>
      </div>

      <div className='header_input'>
    <input type='text' placeholder='Search'/>
    <Searchicon className='header_inputButton' />
      </div>

      <div className='header_right' >

    <VideoCall/>
    <AppsIcon/>
    <NotificationsIcon/>
    <Avatar
    src={Sagar}
    atl='sagardahal'
    />
      </div>
    </div>
  )
}
