import React from 'react'
import './Sidebar.css'
import SidebarRow from '../../SidebarRow/SidebarRow';
import HomeIcon from '@mui/icons-material/Home'
import WhatshotIcon from '@mui/icons-material/Whatshot';
import SubscriptionsIcon from '@mui/icons-material/Subscriptions';
import VideoLibraryIcon from '@mui/icons-material/VideoLibrary';
import HistoryIcon from '@mui/icons-material/History';
import  WatchLaterIcon  from '@mui/icons-material/WatchLater';

export default function Sidebar() {
  return (
    <>
    <div className='sidebar'>
    <SidebarRow  selected title='Home' Icon={HomeIcon}/>
    <SidebarRow title='Explore' Icon={WhatshotIcon}/>
    <SidebarRow title='Subscription' Icon={SubscriptionsIcon}/>
    <SidebarRow title='Library' Icon={VideoLibraryIcon} />
    <SidebarRow title='History' Icon={HistoryIcon} />
    <SidebarRow title='Watch Later' Icon={WatchLaterIcon} /> 
    </div>
    
    
    </>
  )
}
