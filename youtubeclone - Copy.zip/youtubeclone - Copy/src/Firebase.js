const firebaseConfig = {
    apiKey: "AIzaSyDDwtlbsoPVTTQqk_y-0DQsdb6S8U1xcvE",
    authDomain: "clone-9c8b0.firebaseapp.com",
    projectId: "clone-9c8b0",
    storageBucket: "clone-9c8b0.appspot.com",
    messagingSenderId: "754972462036",
    appId: "1:754972462036:web:1577c780a9d2cd1ce86441",
    measurementId: "G-SJQ1YRLN64"
  };