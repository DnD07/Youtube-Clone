import React from 'react'
import Videocard from '../Components/VideoCard/Videocard'
import './RecommendedVideos.css'


export default function RecommendedVideos() {
  return (
      <>
    <div className='videos'>
      <h2>Recommended</h2>
      <div className='recommended_videos'>
    <Videocard 
    title='Football live.'
    image='https://cdn.pixabay.com/photo/2015/04/23/22/00/tree-736885__480.jpg'
    views="2k views"
    channel='Sagar_fu'
    timestamp='2min ago'
    />
    <Videocard 
    title="Sports"
    image=''
    views ='20k views'
    channel='laliga'
    timestamp='40min ago.'
    />
    <Videocard/>
    <Videocard/>
    <Videocard/>

      </div>
    </div>
    </>
  )
}
